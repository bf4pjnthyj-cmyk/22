import { NextResponse } from "next/server";
import { db } from "@/db";
import { lessons, questions } from "@/db/schema";
import { eq, asc } from "drizzle-orm";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const lessonId = parseInt(id);
    
    const lesson = await db.select().from(lessons).where(eq(lessons.id, lessonId)).limit(1);
    if (lesson.length === 0) {
      return NextResponse.json({ error: "Lesson not found" }, { status: 404 });
    }

    const lessonQuestions = await db.select().from(questions)
      .where(eq(questions.lessonId, lessonId))
      .orderBy(asc(questions.orderIndex));

    return NextResponse.json({
      ...lesson[0],
      questions: lessonQuestions,
    });
  } catch (error) {
    console.error("Error fetching lesson:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
