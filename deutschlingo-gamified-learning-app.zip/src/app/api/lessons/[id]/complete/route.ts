import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, lessons, userProgress, streakHistory, achievements, userAchievements } from "@/db/schema";
import { eq, and, sql, count } from "drizzle-orm";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const lessonId = parseInt(id);
    const { score, totalQuestions } = await request.json();
    const userId = 1;
    const stars = score === totalQuestions ? 3 : score >= totalQuestions * 0.7 ? 2 : 1;

    // Get lesson info
    const lesson = await db.select().from(lessons).where(eq(lessons.id, lessonId)).limit(1);
    if (lesson.length === 0) {
      return NextResponse.json({ error: "Lesson not found" }, { status: 404 });
    }

    const xpEarned = lesson[0].xpReward * stars;

    // Upsert progress
    await db.execute(sql`
      INSERT INTO user_progress (user_id, lesson_id, completed, stars, best_score, completed_at)
      VALUES (${userId}, ${lessonId}, true, ${stars}, ${score}, NOW())
      ON CONFLICT (user_id, lesson_id) 
      DO UPDATE SET 
        completed = true,
        stars = GREATEST(user_progress.stars, ${stars}),
        best_score = GREATEST(user_progress.best_score, ${score}),
        completed_at = NOW()
    `);

    // Update user XP
    await db.update(users)
      .set({
        xp: sql`${users.xp} + ${xpEarned}`,
        level: sql`GREATEST(1, (${users.xp} + ${xpEarned}) / 100 + 1)`,
      })
      .where(eq(users.id, userId));

    // Handle streak
    const today = new Date().toISOString().split("T")[0];
    await db.execute(sql`
      INSERT INTO streak_history (user_id, activity_date, xp_earned)
      VALUES (${userId}, ${today}, ${xpEarned})
      ON CONFLICT (user_id, activity_date) 
      DO UPDATE SET xp_earned = streak_history.xp_earned + ${xpEarned}
    `);

    // Calculate streak
    const user = await db.select().from(users).where(eq(users.id, userId)).limit(1);
    const lastActivity = user[0].lastActivityDate;
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split("T")[0];

    let newStreak = user[0].currentStreak;
    if (lastActivity === today) {
      // Already tracked today
    } else if (lastActivity === yesterdayStr) {
      newStreak = user[0].currentStreak + 1;
    } else {
      newStreak = 1;
    }

    const longestStreak = Math.max(newStreak, user[0].longestStreak);

    await db.update(users)
      .set({
        currentStreak: newStreak,
        longestStreak,
        lastActivityDate: today,
      })
      .where(eq(users.id, userId));

    // Check achievements
    const newAchievements: Array<{ title: string; icon: string; description: string }> = [];

    // Count completed lessons
    const completedLessons = await db.select({ value: count() })
      .from(userProgress)
      .where(and(eq(userProgress.userId, userId), eq(userProgress.completed, true)));
    const lessonCount = completedLessons[0].value;

    // Get all achievements
    const allAchievements = await db.select().from(achievements);
    const userAchievementsList = await db.select().from(userAchievements)
      .where(eq(userAchievements.userId, userId));
    const unlockedIds = new Set(userAchievementsList.map(ua => ua.achievementId));

    const updatedUser = await db.select().from(users).where(eq(users.id, userId)).limit(1);

    for (const achievement of allAchievements) {
      if (unlockedIds.has(achievement.id)) continue;

      let shouldUnlock = false;
      if (achievement.category === "lessons" && lessonCount >= achievement.requirement) {
        shouldUnlock = true;
      } else if (achievement.category === "streak" && newStreak >= achievement.requirement) {
        shouldUnlock = true;
      } else if (achievement.category === "xp" && updatedUser[0].xp >= achievement.requirement) {
        shouldUnlock = true;
      } else if (achievement.category === "special" && achievement.key === "perfect_score" && score === totalQuestions) {
        shouldUnlock = true;
      }

      if (shouldUnlock) {
        await db.insert(userAchievements).values({
          userId,
          achievementId: achievement.id,
        });
        await db.update(users)
          .set({ xp: sql`${users.xp} + ${achievement.xpReward}` })
          .where(eq(users.id, userId));
        newAchievements.push({
          title: achievement.title,
          icon: achievement.icon,
          description: achievement.description,
        });
      }
    }

    const finalUser = await db.select().from(users).where(eq(users.id, userId)).limit(1);

    return NextResponse.json({
      xpEarned,
      stars,
      streak: newStreak,
      newAchievements,
      user: finalUser[0],
    });
  } catch (error) {
    console.error("Error completing lesson:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
