import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, streakHistory } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    const user = await db.select().from(users).where(eq(users.id, 1)).limit(1);
    if (user.length === 0) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    const recentActivity = await db.select().from(streakHistory)
      .where(eq(streakHistory.userId, 1))
      .orderBy(desc(streakHistory.activityDate))
      .limit(7);

    // Check if streak is still valid
    const today = new Date().toISOString().split("T")[0];
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split("T")[0];

    const lastActivity = user[0].lastActivityDate;
    const streakActive = lastActivity === today || lastActivity === yesterdayStr;
    const practicedToday = lastActivity === today;

    return NextResponse.json({
      currentStreak: streakActive ? user[0].currentStreak : 0,
      longestStreak: user[0].longestStreak,
      practicedToday,
      recentActivity: recentActivity.map(a => ({
        date: a.activityDate,
        xpEarned: a.xpEarned,
      })),
    });
  } catch (error) {
    console.error("Error fetching streak:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
