import { NextResponse } from "next/server";
import { db } from "@/db";
import { achievements, userAchievements } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const allAchievements = await db.select().from(achievements);
    const userUnlocked = await db.select().from(userAchievements).where(eq(userAchievements.userId, 1));
    const unlockedIds = new Set(userUnlocked.map(ua => ua.achievementId));

    const result = allAchievements.map(a => ({
      ...a,
      unlocked: unlockedIds.has(a.id),
    }));

    return NextResponse.json(result);
  } catch (error) {
    console.error("Error fetching achievements:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
