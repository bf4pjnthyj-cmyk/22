import { NextResponse } from "next/server";
import { db } from "@/db";
import { units, lessons, userProgress } from "@/db/schema";
import { eq, asc } from "drizzle-orm";
import { seedDatabase } from "@/db/seed";

export async function GET() {
  try {
    await seedDatabase();
    
    const allUnits = await db.select().from(units).orderBy(asc(units.orderIndex));
    const allLessons = await db.select().from(lessons).orderBy(asc(lessons.orderIndex));
    const allProgress = await db.select().from(userProgress).where(eq(userProgress.userId, 1));

    const progressMap = new Map(allProgress.map(p => [p.lessonId, p]));

    const result = allUnits.map(unit => {
      const unitLessons = allLessons
        .filter(l => l.unitId === unit.id)
        .map(l => ({
          ...l,
          progress: progressMap.get(l.id) || null,
        }));

      const completedCount = unitLessons.filter(l => l.progress?.completed).length;
      
      return {
        ...unit,
        lessons: unitLessons,
        completedCount,
        totalCount: unitLessons.length,
        isComplete: completedCount === unitLessons.length && unitLessons.length > 0,
      };
    });

    return NextResponse.json(result);
  } catch (error) {
    console.error("Error fetching units:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
