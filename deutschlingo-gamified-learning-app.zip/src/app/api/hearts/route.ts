import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export async function POST(request: Request) {
  try {
    const { action } = await request.json();
    const userId = 1;

    if (action === "lose") {
      await db.update(users)
        .set({ hearts: sql`GREATEST(0, ${users.hearts} - 1)` })
        .where(eq(users.id, userId));
    } else if (action === "refill") {
      const user = await db.select().from(users).where(eq(users.id, userId)).limit(1);
      if (user[0].gems >= 50) {
        await db.update(users)
          .set({
            hearts: 5,
            gems: sql`${users.gems} - 50`,
          })
          .where(eq(users.id, userId));
      } else {
        return NextResponse.json({ error: "Not enough gems" }, { status: 400 });
      }
    }

    const updatedUser = await db.select().from(users).where(eq(users.id, userId)).limit(1);
    return NextResponse.json(updatedUser[0]);
  } catch (error) {
    console.error("Error updating hearts:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
